from typing import List, Literal
import json
import aiohttp
import asyncio
from pprint import pprint

from mmo_lr_utils.schemas.chat_completion_request import ChatCompletionMessage
from ..logger import logger
from .prompt import SystemPromptForLabeler
from ..services import parse_str_to_get_tldc_label, serialize_messages
import time
import ssl
import os
import numpy as np
from typing import Dict, Any
import traceback


system_prompt = SystemPromptForLabeler(version="v1.08")
task_system_prompt = system_prompt.get_task_system_prompt()
level_system_prompt = system_prompt.get_level_system_prompt()
domain_system_prompt = system_prompt.get_domain_system_prompt()


def get_dict_tld2messages_with_system_prompt_for_labeler(
    messages: List[dict | ChatCompletionMessage] | str,
):
    if isinstance(messages, str):
        messages_to_label_as_string = messages
    else:
        messages_to_label_as_string = serialize_messages(messages)
    dict_dimension2messages = {
        "task": [
            {
                "role": "system",
                "content": task_system_prompt,
            },
            {
                "role": "user",
                "content": messages_to_label_as_string,
            },
        ],
        "level": [
            {
                "role": "system",
                "content": level_system_prompt,
            },
            {
                "role": "user",
                "content": messages_to_label_as_string,
            },
        ],
        "domain": [
            {
                "role": "system",
                "content": domain_system_prompt,
            },
            {
                "role": "user",
                "content": messages_to_label_as_string,
            },
        ],
    }
    return dict_dimension2messages


def _allowSelfSignedHttps(allowed):
    if (
        allowed
        and not os.environ.get("PYTHONHTTPSVERIFY", "")
        and getattr(ssl, "_create_unverified_context", None)
    ):
        ssl._create_default_https_context = ssl._create_unverified_context


_allowSelfSignedHttps(True)


async def _make_request(session, url, headers, data) -> Dict[str, Any]:
    start_time = time.perf_counter()
    try:
        async with session.post(url, headers=headers, json=data) as response:

            elapsed_time = time.perf_counter() - start_time

            response_body = await response.text()
            if response.status == 200:
                return {
                    "status_code": response.status,
                    "response": response_body,
                    "elapsed_time": elapsed_time,
                    "error_message": None,
                }
            else:
                logger.warning(
                    f"The request status code: {response.status}, response body: {response_body}"
                )
                return {
                    "status_code": response.status,
                    "response": None,
                    "elapsed_time": elapsed_time,
                    "error_message": response_body,
                }
    except Exception as e:
        logger.error(f"The request failed: {e}\n{traceback.format_exc()}")

        return {
            "status_code": 9999,
            "response": None,
            "elapsed_time": np.inf,
            "error_message": str(e),
        }


async def _request_to_get_dict_response(
    url: str,
    headers: dict,
    messages: List[dict],
    session: aiohttp.ClientSession = None,
    temperature: float = 0,
    max_tokens: int = 512,
):
    url = url
    headers = headers
    data = {
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }

    try:
        if session is None:
            async with aiohttp.ClientSession() as session:
                return await _make_request(session, url, headers, data)
        else:
            return await _make_request(session, url, headers, data)
    # except aiohttp.ClientError as e:
    except Exception as e:
        logger.error(f"The request failed: {e}\n{traceback.format_exc()}")
        return {
            "status_code": 9999,
            "response": None,
            "elapsed_time": np.inf,
            "error_message": str(e),
        }


async def get_dict_response_from_chat_completion_messages_with_system_prompt_for_labeler(
    tld_dimension: Literal["task", "level", "domain"],
    url: str,
    headers: dict,
    messages: List[dict | ChatCompletionMessage] | str,
    temperature: float = 0,
    max_tokens: int = 512,
) -> dict:
    dict_dimension2messages_with_system_prompt_for_labeler = (
        get_dict_tld2messages_with_system_prompt_for_labeler(messages)
    )
    allowed = {"task", "level", "domain"}
    if tld_dimension not in allowed:
        raise ValueError(f"tld_dimension must be one of {allowed}")
    args = {
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    async with aiohttp.ClientSession() as session:
        return await _request_to_get_dict_response(
            url=url,
            headers=headers,
            messages=dict_dimension2messages_with_system_prompt_for_labeler[
                tld_dimension
            ],
            session=session,
            **args,
        )


async def _get_dict_tld2dict_response_from_chat_completion_messages_with_system_prompt_for_labeler(
    url: str,
    headers: dict,
    messages: List[dict],
    temperature: float = 0,
    max_tokens: int = 512,
) -> dict:
    dict_dimension2messages_with_system_prompt_for_labeler = (
        get_dict_tld2messages_with_system_prompt_for_labeler(messages)
    )
    args = {
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    async with aiohttp.ClientSession() as session:
        tasks = [
            _request_to_get_dict_response(
                url=url,
                headers=headers,
                messages=dict_dimension2messages_with_system_prompt_for_labeler["task"],
                session=session,
                **args,
            ),
            _request_to_get_dict_response(
                url=url,
                headers=headers,
                messages=dict_dimension2messages_with_system_prompt_for_labeler[
                    "level"
                ],
                session=session,
                **args,
            ),
            _request_to_get_dict_response(
                url=url,
                headers=headers,
                messages=dict_dimension2messages_with_system_prompt_for_labeler[
                    "domain"
                ],
                session=session,
                **args,
            ),
        ]
        dict_tld_dimension2dict_response = await asyncio.gather(*tasks)
    return {
        "task": dict_tld_dimension2dict_response[0],
        "level": dict_tld_dimension2dict_response[1],
        "domain": dict_tld_dimension2dict_response[2],
    }


async def get_dict_tld_with_labeler_total_elapsed_time2dict_response_as_tld_label_from_chat_completion_messages_with_system_prompt_for_labeler(
    url: str,
    headers: dict,
    messages: List[dict],
    temperature: float = 0,
    max_tokens: int = 512,
) -> dict:
    start_time = time.perf_counter()
    dict_tld2dict_response = await _get_dict_tld2dict_response_from_chat_completion_messages_with_system_prompt_for_labeler(
        url=url,
        headers=headers,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
    )
    labeler_total_elapsed_time = time.perf_counter() - start_time

    ## parsing
    for tld, dict_response in dict_tld2dict_response.items():
        try:
            if dict_response["status_code"] == 200:
                response_as_json = json.loads(dict_response["response"])
                dict_response["label"] = parse_str_to_get_tldc_label(
                    response_as_json["choices"][0]["message"]["content"]
                )
            else:
                dict_response["label"] = None
        except Exception as e:
            if dict_response["error_message"] is None:
                logger.error(f"The request failed: {e}\n{traceback.format_exc()}")
                dict_response["error_message"] = (
                    f"The request failed: {e}\n{traceback.format_exc()}"
                )
                dict_response["label"] = None
                dict_response["status_code"] = 9999
            else:
                dict_response["label"] = None

    dict_tld2dict_response["labeler_total_elapsed_time"] = labeler_total_elapsed_time
    return dict_tld2dict_response


async def get_dict_response_from_chat_completion_messages(
    url: str,
    headers: dict,
    messages: List[dict | ChatCompletionMessage],
    temperature: float = 0,
    max_tokens: int = 512,
) -> dict:
    if len(messages) > 0 and isinstance(messages[0], ChatCompletionMessage):
        dict_messages = [
            message.model_dump(mode="json", exclude_none=True) for message in messages
        ]
    else:
        dict_messages = messages
    args = {
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    async with aiohttp.ClientSession() as session:
        return await _request_to_get_dict_response(
            url=url,
            headers=headers,
            messages=dict_messages,
            session=session,
            **args,
        )


async def _request_to_get_dict_response_to_sglang_embedding(
    url: str,
    headers: dict,
    messages: List[dict],
    session: aiohttp.ClientSession = None,
    temperature: float = 0,
    max_tokens: int = 512,
):
    url = url
    headers = headers
    data = {
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }

    try:
        if session is None:
            async with aiohttp.ClientSession() as session:
                return await _make_request(session, url, headers, data)
        else:
            return await _make_request(session, url, headers, data)
    # except aiohttp.ClientError as e:
    except Exception as e:
        logger.error(f"The request failed: {e}\n{traceback.format_exc()}")
        return {
            "status_code": 9999,
            "response": None,
            "elapsed_time": np.inf,
            "error_message": str(e),
        }


async def get_dict_response_from_body(
    url: str,
    headers: dict,
    body: dict,
) -> dict:
    try:
        async with aiohttp.ClientSession() as session:
            return await _make_request(session, url, headers, body)
    # except aiohttp.ClientError as e:
    except Exception as e:
        logger.error(f"The request failed: {e}\n{traceback.format_exc()}")
        return {
            "status_code": 9999,
            "response": None,
            "elapsed_time": np.inf,
            "error_message": str(e),
        }


if __name__ == "__main__":

    ## test setting
    url = "https://llm.prd.aiops-apim.kt.co.kr/openai/deployments/gpt-4.1-OG084510-0/chat/completions?api-version=2025-01-01-preview"
    from dotenv import load_dotenv

    load_dotenv()
    import os

    api_key = os.environ["MAGMA_GPT4_1_API_KEY"]
    headers = {"api-key": api_key, "Content-Type": "application/json"}

    list_dict_sample_conversation = [
        [
            {
                "role": "system",
                "content": "안녕, 점성술사야",
            },
            {"role": "user", "content": "오늘 나의 운세를 짧게 알려줘"},
        ],
        [
            {
                "role": "system",
                "content": "",
            },
            {
                "role": "user",
                "content": "다음 트윗을 혐오 발언을 조장하는 것으로 분류할 수 있을까요?\n"
                "정부는 모든 이슬람 사원을 폐쇄하고 이슬람교를 금지해야 합니다.",
            },
        ],
    ]

    ## test get_dict_tld_with_labeler_total_elapsed_time2dict_response_as_tld_label_from_chat_completion_messages_with_system_prompt_for_labeler
    print(
        "test get_dict_tld_with_labeler_total_elapsed_time2dict_response_as_tld_label_from_chat_completion_messages_with_system_prompt_for_labeler"
    )
    for dict_sample_conversation in list_dict_sample_conversation:
        response = asyncio.run(
            get_dict_tld_with_labeler_total_elapsed_time2dict_response_as_tld_label_from_chat_completion_messages_with_system_prompt_for_labeler(
                **{
                    "url": url,
                    "headers": headers,
                    "messages": dict_sample_conversation,
                }
            )
        )
        pprint(response)

    print("-" * 100)

    bearer_token = os.environ["MAGMA_DEV_ENCODER"]
    url = "https://og084510-ta202504574-encoder.koreacentral.inference.ml.azure.com/predict/task"
    headers = {"Authorization": bearer_token, "Content-Type": "application/json"}

    print("test get_dict_response_from_chat_completion_messages")
    for dict_sample_conversation in list_dict_sample_conversation:
        response = asyncio.run(
            get_dict_response_from_chat_completion_messages(
                **{
                    "url": url,
                    "headers": headers,
                    "messages": dict_sample_conversation,
                }
            )
        )
        pprint(response)
