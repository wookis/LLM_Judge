#!/usr/bin/env python3
import json
from pathlib import Path
from typing import Optional
from ..logger import logger


class SystemPromptForLabeler:
    path_prompt_root_dir = Path(__file__).parent / "prompt"

    def __init__(
        self,
        version: str = "v1.08",
        path_task_system_prompt: Optional[Path] = None,
        path_level_system_prompt: Optional[Path] = None,
        path_domain_system_prompt: Optional[Path] = None,
    ):
        logger.info(f"Loading prompts for version: {version}")
        self.version = version
        self.id = f"labeler_prompt_{self.version}"
        if path_task_system_prompt is None:
            path_task_system_prompt = (
                SystemPromptForLabeler.path_prompt_root_dir
                / version
                / f"system-prompt-{version}_Task.txt"
            )
        if path_level_system_prompt is None:
            path_level_system_prompt = (
                SystemPromptForLabeler.path_prompt_root_dir
                / version
                / f"system-prompt-{version}_Level.txt"
            )
        if path_domain_system_prompt is None:
            path_domain_system_prompt = (
                SystemPromptForLabeler.path_prompt_root_dir
                / version
                / f"system-prompt-{version}_Domain.txt"
            )

        assert (
            path_task_system_prompt.exists()
        ), f"Task system prompt file not found: {path_task_system_prompt}"
        assert (
            path_level_system_prompt.exists()
        ), f"Level system prompt file not found: {path_level_system_prompt}"
        assert (
            path_domain_system_prompt.exists()
        ), f"Domain system prompt file not found: {path_domain_system_prompt}"

        with open(path_task_system_prompt, "r", encoding="utf-8") as f:
            self.task_system_prompt = json.dumps(f.read(), ensure_ascii=False).strip()
        with open(path_level_system_prompt, "r", encoding="utf-8") as f:
            self.level_system_prompt = json.dumps(f.read(), ensure_ascii=False).strip()
        with open(path_domain_system_prompt, "r", encoding="utf-8") as f:
            self.domain_system_prompt = json.dumps(f.read(), ensure_ascii=False).strip()

    def get_task_system_prompt(self) -> str:
        return self.task_system_prompt

    def get_level_system_prompt(self) -> str:
        return self.level_system_prompt

    def get_domain_system_prompt(self) -> str:
        return self.domain_system_prompt

    def get_version(self) -> str:
        return self.version

    def get_id(self) -> str:
        return self.id


if __name__ == "__main__":
    system_prompt = SystemPromptForLabeler()
    print(f"Task System Prompt:\n{system_prompt.get_task_system_prompt()}\n")
    print(f"Level System Prompt:\n{system_prompt.get_level_system_prompt()}\n")
    print(f"Domain System Prompt:\n{system_prompt.get_domain_system_prompt()}\n")
