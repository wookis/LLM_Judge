"""
Schemas module for MMO LR Utils.
"""

from .label import TLDCLabelCode
