import logging
from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
import os

# 기본 로그 디렉토리 설정 - 환경변수로 오버라이드 가능
DEFAULT_LOG_DIR = Path(__file__).parent / "logs"
LOG_DIR = Path(os.getenv("MMO_LR_UTILS_LOG_DIR", DEFAULT_LOG_DIR))
LOG_FILE = Path(os.getenv("MMO_LR_UTILS_LOG_FILE", "app.log"))
LOG_LEVEL = os.getenv("MMO_LR_UTILS_LOG_LEVEL", "DEBUG")
LOGGER_NAME = os.getenv("MMO_LR_UTILS_LOGGER_NAME", "MMO_LR_LOGGER")

# 로그 디렉토리 생성
if not LOG_DIR.exists():
    LOG_DIR.mkdir(parents=True, exist_ok=True)

path_log = LOG_DIR / LOG_FILE
log_level = getattr(logging, LOG_LEVEL.upper(), logging.DEBUG)

# 로거 설정
logger = logging.getLogger(LOGGER_NAME)
logger.setLevel(log_level)

# 기존 핸들러 제거 (중복 방지)
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# 콘솔 핸들러 추가
console_handler = logging.StreamHandler()
console_handler.setLevel(log_level)

# 파일 핸들러 추가 (Databricks 호환을 위해 일반 FileHandler 사용)
file_handler = logging.FileHandler(path_log)
file_handler.setLevel(log_level)


class KSTFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):
        dt = datetime.fromtimestamp(record.created, ZoneInfo("Asia/Seoul"))
        return dt.strftime(datefmt) if datefmt else dt.isoformat()


# 포맷 설정
formatter = KSTFormatter("%(asctime)s - %(levelname)s - %(message)s")
console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# 로거에 핸들러 추가
logger.addHandler(console_handler)
logger.addHandler(file_handler)


def configure_logger(
    log_dir=None,
    log_file=None,
    log_level_param=None,
    console_output=True,
    file_output=True,
):
    """
    로거를 외부에서 설정할 수 있는 함수

    Args:
        log_dir (str or Path): 로그 디렉토리 경로
        log_file (str): 로그 파일명
        log_level_param (str): 로그 레벨 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        console_output (bool): 콘솔 출력 여부
        file_output (bool): 파일 출력 여부
    """
    global logger, path_log, log_level

    # 기존 핸들러 제거
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # 설정값 적용
    if log_dir is not None:
        log_dir = Path(log_dir)
        if not log_dir.exists():
            log_dir.mkdir(parents=True, exist_ok=True)
        path_log = log_dir / (log_file or "app.log")
    elif log_file is not None:
        path_log = LOG_DIR / log_file

    if log_level_param is not None:
        global_log_level = getattr(logging, log_level_param.upper(), logging.DEBUG)
        log_level = global_log_level
        logger.setLevel(global_log_level)

    # 콘솔 핸들러 추가
    if console_output:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(log_level)

        class KSTFormatter(logging.Formatter):
            def formatTime(self, record, datefmt=None):
                dt = datetime.fromtimestamp(record.created, ZoneInfo("Asia/Seoul"))
                return dt.strftime(datefmt) if datefmt else dt.isoformat()

        formatter = KSTFormatter("%(asctime)s - %(levelname)s - %(message)s")
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    # 파일 핸들러 추가 (Databricks 호환을 위해 일반 FileHandler 사용)
    if file_output:
        file_handler = logging.FileHandler(path_log)
        file_handler.setLevel(log_level)

        class KSTFormatter(logging.Formatter):
            def formatTime(self, record, datefmt=None):
                dt = datetime.fromtimestamp(record.created, ZoneInfo("Asia/Seoul"))
                return dt.strftime(datefmt) if datefmt else dt.isoformat()

        formatter = KSTFormatter("%(asctime)s - %(levelname)s - %(message)s")
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
