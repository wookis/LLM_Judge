from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime
import json
from ..services.messages_serializer import serialize_messages


class MessageRole(str, Enum):
    System = "system"
    User = "user"
    Assistant = "assistant"


class Message(BaseModel):
    role: MessageRole  # "system", "user", or "assistant"
    content: str  # The actual message content
    timestamp: Optional[datetime] = None  # Optional timestamp for the message
    metadata: Optional[Dict[str, Any]] = None  # Optional


class Conversation(BaseModel):
    metadata: Optional[Dict[str, Any]] = None  # Optional metadata for the conversation
    messages: List[Message]  # The conversation object
    # To-Do: tools, tool-choice, etc.


def generate_list_dict_message_from_conversation(
    conversation: Conversation,
) -> List[Dict[str, str]]:
    """
    Converts a Conversation object into a list of dictionaries with 'role' and 'content' keys.

    Args:
        conversation (Conversation): The Conversation object to convert.

    Returns:
        List[Dict[str, str]]: A list of dictionaries representing the messages.
    """
    return [
        {"role": message.role.value, "content": message.content}
        for message in conversation.messages
    ]


def generate_str_for_labeling_without_metadata(conversation: Conversation) -> str:
    conversation.metadata = None
    for message in conversation.messages:
        message.metadata = None
        message.timestamp = None
    return serialize_messages(conversation.messages)


## for Assertions for Argilla
class MmoLabel(BaseModel):
    version: str
    task: List[str]
    level: List[str]
    domain: List[str]
    capability: List[str]


class MmoTestcase(BaseModel):
    metadata: Optional[Dict[str, Any]] = None  # Optional metadata for the dataset
    input: Conversation
    oracle: MmoLabel


def test_conversation():
    message1 = Message(role="user", content="Hello, how are you?")
    message2 = Message(
        role="assistant", content="I'm fine, thank you!", timestamp=datetime.now()
    )

    conversation = Conversation(messages=[message1, message2])
    print(f"conversation\n{conversation.model_dump_json(indent=4)}")

    user_query = json.dumps(generate_str_for_labeling_without_metadata(conversation))
    print(f"user_query\n{user_query}")

    dataset = [{"vars": {"id": 1, "user_query": user_query}}]
    print(f"dataset\n{dataset}")


if __name__ == "__main__":
    test_conversation()
